import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-public-devises',
  templateUrl: './public-devises.component.html',
  styleUrls: ['./public-devises.component.scss']
})
export class PublicDevisesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
