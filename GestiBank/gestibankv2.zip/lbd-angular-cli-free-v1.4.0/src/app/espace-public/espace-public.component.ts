import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-espace-public',
  templateUrl: './espace-public.component.html',
  styleUrls: ['./espace-public.component.scss']
})
export class EspacePublicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
