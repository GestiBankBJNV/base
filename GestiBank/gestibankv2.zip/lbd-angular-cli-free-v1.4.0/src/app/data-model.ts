export class Conseiller {
  	matricule: '';
	username: '';
	email: '';
	prenom: '';
	nom: '';
	adresse: '';
	ville: '';
	pays: '';
	cp: '';
	infos: '';
}

export class Adresse {
	rue = "";
  	ville  = "";
  	CP  = ""; 
  
}

