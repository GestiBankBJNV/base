//Dummy Operation
export class Operation {
	date : Date;
	libelle : String;
	type : String;
	montant : Number;
}
