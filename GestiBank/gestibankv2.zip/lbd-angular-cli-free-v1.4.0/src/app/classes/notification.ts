//Dummy Notification
export class Notification {
	libelle : String;
	date : Date;
	isRead : Boolean;
}