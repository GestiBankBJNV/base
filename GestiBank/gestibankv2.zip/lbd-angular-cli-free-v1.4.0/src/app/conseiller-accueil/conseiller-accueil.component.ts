import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conseiller-accueil',
  templateUrl: './conseiller-accueil.component.html',
  styleUrls: ['./conseiller-accueil.component.scss']
})
export class ConseillerAccueilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
