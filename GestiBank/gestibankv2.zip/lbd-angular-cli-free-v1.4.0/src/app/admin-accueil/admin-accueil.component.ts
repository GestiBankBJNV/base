import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-accueil',
  templateUrl: './admin-accueil.component.html',
  styleUrls: ['./admin-accueil.component.scss']
})
export class AdminAccueilComponent implements OnInit {

  	constructor() { }

  	ngOnInit() {
  	}

  
}
