package com.gk.gestibank.dao;

public interface CompteEpargneDao {

}
