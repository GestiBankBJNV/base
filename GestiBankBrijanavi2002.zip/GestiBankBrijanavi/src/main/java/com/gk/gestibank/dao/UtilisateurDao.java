package com.gk.gestibank.dao;

import com.gk.gestibank.model.DemandeInscription;

public interface UtilisateurDao {
	public void demanderInscription(DemandeInscription demandeInscription);
	// todo: autres m�thodes ?
}
