package com.gk.gestibank.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.gk.gestibank.dao.ClientDao;
import com.gk.gestibank.dao.NotificationDao;
import com.gk.gestibank.model.Notification;

@Repository
public class NotificationDaoImpl implements NotificationDao {
	
	@Autowired
	ClientDao clientDao;
	
	@PersistenceContext
	EntityManager em;
	
	public NotificationDaoImpl(){}	
	
	
	public List<Notification> getByClient(int clientId) {
		
		//TODO : � remplacer
		List<Notification> l = new ArrayList<Notification>(); 
		
		for (int i=0; i < 20; i++) {
			Notification n = new Notification(new Date(),"Notification " + i, "notif", (i > 5));
			n.setId(i);
			l.add(n);
		}
		
		return l;
		//return clientDao.getClientById(clientId).getNotifications();		
	}
	
	@Transactional
	public boolean delete(int notificationId){
		Notification n = new Notification(new Date(), "hello!", "not", false);
		em.persist(n);
		//TODO
		return true;
	}
	
	
	public boolean addToClient(int clientId, Notification notification){
		//TODO
		return true;
	}

	
	public boolean update(Notification notification) {
		//TODO
		return true;
	}
}
